//
//  LGPerson.m
//  KCObjc
//
//  Created by Cooci on 2020/7/24.
//

#import "MyPerson.h"

@implementation MyPerson

//+(void)load {
//    NSLog(@"%s",__func__);
//}

+ (void)initialize
{
    if (self == [self class]) {
        NSLog(@"%s",__func__);
    }
}


- (void)funcInstanceTest {
    NSLog(@"hello, funcInstanceTest");

}
- (void)helloObj1 {
    NSLog(@"hello, helloObj1");
}

+ (void)funcClassTest {
    NSLog(@"hello, funcClassTest");

}

@end
