//
//  MyPerson+cateTwo.m
//  KCObjc
//
//  Created by Domy on 2020/10/24.
//

#import "MyPerson+cateTwo.h"

#import <AppKit/AppKit.h>


@implementation MyPerson (cateTwo)

//+ (void)load {
//    NSLog(@"func: %s",__func__);
//}

+ (void)initialize
{
    if (self == [super class]) {
       NSLog(@"func: %s",__func__);
    }
}



- (void)helloObj1 {
    NSLog(@"func: %s",__func__);
}

- (void)helloCateTwoInstance {
    NSLog(@"func: %s",__func__);
}
+ (void)helloCateTwoClass{
    NSLog(@"func: %s",__func__);
}

@end
