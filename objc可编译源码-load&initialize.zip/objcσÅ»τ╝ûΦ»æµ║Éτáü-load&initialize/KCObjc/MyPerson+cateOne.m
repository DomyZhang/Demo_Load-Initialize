//
//  MyPerson+cateOne.m
//  KCObjc
//
//  Created by Domy on 2020/10/24.
//

#import "MyPerson+cateOne.h"

#import <AppKit/AppKit.h>


@implementation MyPerson (cateOne)

//+(void)load {
//    NSLog(@"%s",__func__);
//}

//+ (void)initialize
//{
//    if (self == [super class]) {
//       NSLog(@"func: %s",__func__);
//    }
//}


- (void)helloObj1 {
    NSLog(@"func: %s",__func__);
}

- (void)helloCateOneInstance{
    NSLog(@"%s",__func__);
}
+ (void)helloCateOneClass {
    NSLog(@"%s",__func__);
}

@end
