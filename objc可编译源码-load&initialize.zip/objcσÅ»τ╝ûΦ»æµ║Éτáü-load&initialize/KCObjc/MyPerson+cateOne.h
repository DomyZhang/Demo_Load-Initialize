//
//  MyPerson+cateOne.h
//  KCObjc
//
//  Created by Domy on 2020/10/24.
//

#import <AppKit/AppKit.h>


#import "MyPerson.h"

NS_ASSUME_NONNULL_BEGIN

@interface MyPerson (cateOne)

- (void)helloCateOneInstance;
+ (void)helloCateOneClass;

@end

NS_ASSUME_NONNULL_END
