//
//  LGPerson.h
//  KCObjc
//
//  Created by Cooci on 2020/7/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyPerson : NSObject

@property (nonatomic, copy) NSString *testpName;
@property (nonatomic, assign) NSInteger age;

- (void)funcInstanceTest;
- (void)helloObj1;
+ (void)funcClassTest;

@end

NS_ASSUME_NONNULL_END
