//
//  MyPerson+cateTwo.h
//  KCObjc
//
//  Created by Domy on 2020/10/24.
//

#import <AppKit/AppKit.h>


#import "MyPerson.h"

NS_ASSUME_NONNULL_BEGIN

@interface MyPerson (cateTwo)

- (void)helloCateTwoInstance;
+ (void)helloCateTwoClass;

@end

NS_ASSUME_NONNULL_END
